<html>
<body>
<?php
echo $php_array[1];
?>
</body>
</html>
