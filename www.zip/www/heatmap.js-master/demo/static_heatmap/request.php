<?php
include('array.php');
include('final.html');
?>
